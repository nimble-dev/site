"benchstats" <-
structure(c(1.542340069, 0.425336542871729, 0.0095108142317594, 
0.0141467677072243), .Names = c("Mean", "SD", "Naive SE", "Time-series SE"
))
