
if(!exists('.NimbleUseRegistration') || !.NimbleUseRegistration) {
    message('Error: C function registrations are not set up correctly.')
}
