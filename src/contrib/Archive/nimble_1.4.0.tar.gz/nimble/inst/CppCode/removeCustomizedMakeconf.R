if(file.exists('Makeconf')) {
    file.remove('Makeconf')
}
