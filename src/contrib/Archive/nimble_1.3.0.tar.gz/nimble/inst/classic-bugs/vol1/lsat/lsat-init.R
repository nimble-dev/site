"alpha" <- c(0,0,0,0,0)
"beta" <-  1
