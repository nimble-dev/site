"beta" <- c(-13,-13,-13,-13)
"r" <- 4
"t" <-
c(NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
NA, NA, 41, NA, NA, NA, NA, NA, NA, NA, 41, 41, NA, NA, NA, 41, 
NA, 41, 41, 41, 41, NA, NA, NA, NA, NA, NA, 11, NA, NA, NA, NA, 
NA, NA, NA, NA, NA, 25, NA, 41, 41, NA, NA, NA, NA, NA, NA, NA, 
NA, NA, NA, NA, 21, NA, NA, NA, NA, 30, 11, NA, NA, NA, NA, NA, 
NA)
